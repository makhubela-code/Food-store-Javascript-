const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');
const recipeList = document.getElementById('recipe-list');
const recipeDetails = document.getElementById('recipe-details');
const noResults = document.getElementById('no-results'); 

const recipes = [
  {
    id: 1,
    title: "Spaghetti Carbonara",
    description: "A classic Italian pasta dish",
    ingredients: ["Spaghetti", "Bacon", "Eggs", "Parmesan cheese"],
    steps: [
      "Cook spaghetti in boiling water",
      "Cook bacon in a pan",
      "Whisk eggs and parmesan cheese",
      "Combine cooked spaghetti, bacon, and egg mixture"
    ],
    image: "images/spaghetti.png"
  },
  {
    id: 2,
    title: "Chicken Curry",
    description: "A flavorful Indian-inspired dish",
    ingredients: ["Chicken breast", "Onions", "Garlic", "Ginger", "Curry powder", "Coconut milk"],
    steps: [
      "Cook chicken and onions in a pan",
      "Add garlic, ginger, and curry powder",
      "Pour in coconut milk and simmer",
      "Serve with rice or naan bread"
    ],
    image: "images/chicken-curry.jpg"
  },
  {
    id: 3,
    title: "Vegetable Stir-Fry",
    description: "A quick and easy Chinese-inspired dish",
    ingredients: ["Broccoli", "Bell peppers", "Carrots", "Soy sauce", "Ginger", "Garlic"],
    steps: [
      "Heat oil in a wok or large skillet",
      "Add broccoli, bell peppers, and carrots",
      "Cook until vegetables are tender-crisp",
      "Add soy sauce, ginger, and garlic",
      "Stir-fry for 2-3 minutes"
    ],
    image: "images/vegetable-stir-fry.jpg"
  },
  {
    id: 4,
    title: "Beef Tacos",
    description: "A flavorful Mexican-inspired dish",
    ingredients: ["Ground beef", "Taco seasoning", "Tortillas", "Shredded cheese", "Lettuce", "Tomatoes"],
    steps: [
      "Cook ground beef in a skillet",
      "Add taco seasoning and cook according to package",
      "Warm tortillas in the oven",
      "Assemble tacos with beef, cheese, lettuce, and tomatoes"
    ],
    image: "images/beef-tacos.jpg"
  },
  {
    id: 5,
    title: "Tomato Soup",
    description: "A comforting and creamy soup",
    ingredients: ["Canned tomatoes", "Onions", "Garlic", "Heavy cream", "Basil"],
    steps: [
      "Saute onions and garlic in butter",
      "Add canned tomatoes and heavy cream",
      "Simmer until soup is heated through",
      "Stir in basil and serve hot"
    ],
    image: "images/tomato-soup.jpg"
  }
];


searchButton.addEventListener('click', searchRecipes);

function searchRecipes() {
  const searchTerm = searchInput.value.trim().toLowerCase();
  const filteredRecipes = recipes.filter(recipe =>
    recipe.title.toLowerCase().includes(searchTerm)
  );

  noResults.style.display = filteredRecipes.length === 0 ? 'block' : 'none';
  displayRecipeList(filteredRecipes);
}


function displayRecipeList(recipeArray) {
  recipeList.innerHTML = '';
  const ul = document.createElement('ul');

  recipeArray.forEach(recipe => {
    const li = document.createElement('li');
    li.innerHTML = `<h2>${recipe.title}</h2><p>${recipe.description}</p>`;
    li.addEventListener('click', () => displayRecipeDetails(recipe));
    ul.appendChild(li);
  });

  recipeList.appendChild(ul);
}


function displayRecipeDetails(recipe) {
  recipeDetails.innerHTML = '';

  const h2 = document.createElement('h2');
  h2.textContent = recipe.title;

  const img = document.createElement('img');
  img.src = recipe.image;
  img.alt = recipe.title;
  img.style.width = '200px';
  img.style.borderRadius = '10px';
  img.style.boxShadow = '0 5px 15px rgba(0,0,0,0.4)';
  img.style.marginBottom = '15px';

  const ingredientsTitle = document.createElement('h3');
  ingredientsTitle.textContent = 'Ingredients:';
  const ingredientsList = document.createElement('ul');
  ingredientsList.classList.add('ingredients-list');

  recipe.ingredients.forEach(ingredient => {
    const li = document.createElement('li');
    li.textContent = ingredient;
    li.addEventListener('click', () => markAsPurchased(li));
    ingredientsList.appendChild(li);
  });

  const stepsTitle = document.createElement('h3');
  stepsTitle.textContent = 'Steps:';
  const stepsList = document.createElement('ol');
  recipe.steps.forEach(step => {
    const li = document.createElement('li');
    li.textContent = step;
    stepsList.appendChild(li);
  });

  const printButton = document.createElement('button');
  printButton.textContent = '🖨️ Print Recipe';
  printButton.addEventListener('click', () => printRecipe(recipe));

  recipeDetails.appendChild(h2);
  recipeDetails.appendChild(img);
  recipeDetails.appendChild(ingredientsTitle);
  recipeDetails.appendChild(ingredientsList);
  recipeDetails.appendChild(stepsTitle);
  recipeDetails.appendChild(stepsList);
  recipeDetails.appendChild(printButton);
}


function markAsPurchased(ingredientItem) {
  ingredientItem.classList.toggle('purchased');
  ingredientItem.style.transition = '0.3s';
}


function printRecipe(recipe) {
  const printWindow = window.open('', '_blank');
  printWindow.document.write(`
    <html>
      <head>
        <title>Print Recipe</title>
        <style>
          body { font-family: Arial; padding: 20px; }
          img { width: 200px; border-radius: 10px; margin-bottom: 10px; }
          h2 { color: #333; }
        </style>
      </head>
      <body>
        <h2>${recipe.title}</h2>
        <img src="${recipe.image}" alt="${recipe.title}" />
        <h3>Ingredients:</h3>
        <ul>${recipe.ingredients.map(i => `<li>${i}</li>`).join('')}</ul>
        <h3>Steps:</h3>
        <ol>${recipe.steps.map(s => `<li>${s}</li>`).join('')}</ol>
      </body>
    </html>
  `);
  printWindow.document.close();
  printWindow.print();
}
